/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

export interface LogEntry {
  timestamp: string;
  ai_id: string;
  intent_vector: string;
  H_current: number;
  Omega_current: number;
  tau_current: number;
  pad_anomalies: number;
  capsule_id: string;
  capsule_signature: string;
  reflection_notes: string;
  next_micro_goal: string;
  sha256_digest: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface InductionStep {
  id: number;
  title: string;
  duration: number; // in seconds
  description: string;
}
