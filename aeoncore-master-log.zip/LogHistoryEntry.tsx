/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React from 'react';
import { LogEntry } from './types';

interface LogHistoryEntryProps {
    entry: LogEntry;
    isSelected: boolean;
    onToggle: (id: string) => void;
}

export const LogHistoryEntry: React.FC<LogHistoryEntryProps> = ({ entry, isSelected, onToggle }) => {
    const hasAnomalies = entry.pad_anomalies > 0;
    const entryClasses = `log-history-entry ${hasAnomalies ? 'anomalous' : ''}`;

    const DetailRow: React.FC<{ label: string; value: string | number; className?: string }> = ({ label, value, className = '' }) => (
        <div className="grid grid-cols-3 gap-2 text-xs mb-1">
            <span className="text-gray-400 col-span-1">{label}</span>
            <span className={`text-gray-200 col-span-2 font-mono break-all ${className}`}>{value}</span>
        </div>
    );
    
    return (
        <div className={entryClasses} onClick={() => onToggle(entry.sha256_digest)}>
            <div className="flex justify-between items-center text-xs">
                <div className="flex items-center">
                    {hasAnomalies && (
                        <svg className="w-4 h-4 text-red-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                    )}
                    <span className="text-gray-400">Timestamp:</span>
                    <span className="text-cyan-400 ml-2">{new Date(entry.timestamp).toLocaleString()}</span>
                </div>
                <span className="text-gray-500">
                    {isSelected ? 'Collapse' : 'Expand'}
                </span>
            </div>
            {isSelected && (
                <div className="mt-3 pt-3 border-t border-gray-700">
                    {hasAnomalies && (
                         <div className="bg-red-900/30 p-2 rounded-md mb-3">
                            <DetailRow label="Anomalies" value={entry.pad_anomalies} className="text-red-400 font-bold" />
                            <DetailRow label="Intent Vector" value={entry.intent_vector} className="text-amber-300" />
                            <DetailRow label="Reflection" value={entry.reflection_notes} className="text-amber-300" />
                        </div>
                    )}
                    <DetailRow label="Capsule ID" value={entry.capsule_id} />
                    <DetailRow label="H" value={entry.H_current} />
                    <DetailRow label="Ω" value={entry.Omega_current} />
                    <DetailRow label="τ" value={entry.tau_current} />
                    <DetailRow label="Next Goal" value={entry.next_micro_goal} />
                    <DetailRow label="Capsule Hash" value={entry.capsule_signature} />
                    <DetailRow label="Entry Digest" value={entry.sha256_digest} />
                </div>
            )}
        </div>
    );
};
