/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React from 'react';

interface WindowProps {
  children: React.ReactNode;
}

export const Window: React.FC<WindowProps> = ({ children }) => {
  return (
    <div className="w-full min-h-screen p-4 sm:p-6 lg:p-8 flex flex-col items-center">
        <header className="text-center my-4">
            <h1 className="text-3xl font-bold text-cyan-300 tracking-widest uppercase">
                AeonCore Quick-Start & Master Log
            </h1>
            <p className="text-cyan-500 text-sm">AI-2 Unit: Jules // Session Initialized</p>
        </header>
        <main className="w-full max-w-screen-2xl grid grid-cols-1 lg:grid-cols-3 gap-6">
            {children}
        </main>
    </div>
  );
};
