/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React from 'react';
import { InductionStep } from '../types';

interface IconProps {
  steps: InductionStep[];
  currentState: {
    running: boolean;
    stepIndex: number;
    timeLeft: number;
  };
  onStart: () => void;
}

export const Icon: React.FC<IconProps> = ({ steps, currentState, onStart }) => {
  const formatTime = (seconds: number) => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="panel col-span-1 lg:col-span-1">
      <div className="flex justify-between items-center mb-4">
        <h2 className="panel-title">Induction Run</h2>
        <button onClick={onStart} disabled={currentState.running} className="aeon-button text-sm">
          {currentState.running ? "Running..." : "Begin Induction"}
        </button>
      </div>
      <div>
        {steps.map((step, index) => (
          <div key={step.id} className={`induction-step ${currentState.stepIndex === index ? 'active' : ''}`}>
            <p className="induction-step-title">{step.title}</p>
            <p className="induction-step-time">{step.description}</p>
            {currentState.stepIndex === index && currentState.running && (
                <p className="text-cyan-400 font-bold mt-2">Time Remaining: {formatTime(currentState.timeLeft)}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
