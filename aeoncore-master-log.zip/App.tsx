/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Window } from './Window';
import { ParametersPanel } from './ParametersPanel';
import { GeneratedContent } from './GeneratedContent';
import { Icon } from './Icon';
import { TelemetryGraph } from './TelemetryGraph';
import { INITIAL_CHECKLIST_ITEMS, INDUCTION_STEPS, getInitialLogEntry, INITIAL_LOG_HISTORY } from './constants';
import { ChecklistItem, LogEntry } from './types';
import { calculateSHA256 } from './services/geminiService';

const getNextCapsuleId = (history: LogEntry[]): string => {
  if (!history || history.length === 0) {
    return "IC-J0";
  }
  const latestEntry = history[0];
  const lastId = latestEntry.capsule_id;
  const lastNumMatch = lastId.match(/-J(\d+)$/);
  if (lastNumMatch && lastNumMatch[1]) {
    const lastNum = parseInt(lastNumMatch[1], 10);
    return `IC-J${lastNum + 1}`;
  }
  // Fallback for non-standard IDs or IC-J0
  return `IC-J${history.length}`;
};


const App: React.FC = () => {
  const [logEntry, setLogEntry] = useState<LogEntry>(() => getInitialLogEntry(getNextCapsuleId(INITIAL_LOG_HISTORY)));
  const [logHistory, setLogHistory] = useState<LogEntry[]>(INITIAL_LOG_HISTORY);
  const [checklist, setChecklist] = useState<ChecklistItem[]>(INITIAL_CHECKLIST_ITEMS);
  const [inductionState, setInductionState] = useState({ running: true, stepIndex: 0, timeLeft: INDUCTION_STEPS[0].duration });
  const [isSealing, setIsSealing] = useState(false);
  const [selectedLogId, setSelectedLogId] = useState<string | null>(null);
  const timerRef = useRef<number | null>(null);

  const handleUpdateEntry = (field: keyof LogEntry, value: string | number) => {
    setLogEntry(prev => ({ ...prev, [field]: value }));
  };

  const handleToggleChecklistItem = (id: string) => {
    setChecklist(prev => prev.map(item => item.id === id ? { ...item, completed: !item.completed } : item));
  };
  
  const handleToggleLogDetail = (id: string) => {
    setSelectedLogId(prevId => (prevId === id ? null : id));
  };

  const runInductionStep = useCallback((stepIdx: number) => {
    if (stepIdx >= INDUCTION_STEPS.length) {
      setInductionState({ running: false, stepIndex: -1, timeLeft: 0 });
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    const currentStep = INDUCTION_STEPS[stepIdx];
    setInductionState({ running: true, stepIndex: stepIdx, timeLeft: currentStep.duration });
  }, []);
  
  useEffect(() => {
    if (inductionState.running && inductionState.timeLeft > 0) {
      timerRef.current = window.setInterval(() => {
        setInductionState(prev => ({ ...prev, timeLeft: prev.timeLeft - 1 }));
      }, 1000);
    } else if (inductionState.running && inductionState.timeLeft <= 0) {
      if (timerRef.current) clearInterval(timerRef.current);
      runInductionStep(inductionState.stepIndex + 1);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [inductionState.running, inductionState.timeLeft, inductionState.stepIndex, runInductionStep]);

  const handleStartInduction = () => {
    if (!inductionState.running) {
      runInductionStep(0);
    }
  };

  const handleSealCapsule = useCallback(async () => {
    setIsSealing(true);
    const capsuleContent = { ...logEntry };
    delete capsuleContent.capsule_signature;
    delete capsuleContent.sha256_digest;
    
    const capsuleSignature = await calculateSHA256(JSON.stringify(capsuleContent, Object.keys(capsuleContent).sort(), 2));
    
    const finalEntry = { ...logEntry, capsule_signature: capsuleSignature, timestamp: new Date().toISOString() };
    const finalEntrySignature = await calculateSHA256(JSON.stringify(finalEntry, Object.keys(finalEntry).sort(), 2));
    
    const sealedEntry = { ...finalEntry, sha256_digest: finalEntrySignature };
    
    const newHistory = [sealedEntry, ...logHistory];
    setLogHistory(newHistory);
    setLogEntry(getInitialLogEntry(getNextCapsuleId(newHistory)));
    setIsSealing(false);
  }, [logEntry, logHistory]);
  
  return (
    <Window>
      <ParametersPanel checklist={checklist} onToggleItem={handleToggleChecklistItem} />
      <GeneratedContent 
        logEntry={logEntry} 
        logHistory={logHistory} 
        onUpdateEntry={handleUpdateEntry}
        onSealCapsule={handleSealCapsule}
        isSealing={isSealing}
        selectedLogId={selectedLogId}
        onToggleDetail={handleToggleLogDetail}
      />
      <Icon steps={INDUCTION_STEPS} currentState={inductionState} onStart={handleStartInduction} />
      <TelemetryGraph logHistory={logHistory} />
    </Window>
  );
};

export default App;