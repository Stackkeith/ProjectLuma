/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React from 'react';
import { ChecklistItem } from './types';

interface ParametersPanelProps {
  checklist: ChecklistItem[];
  onToggleItem: (id: string) => void;
}

export const ParametersPanel: React.FC<ParametersPanelProps> = ({ checklist, onToggleItem }) => {
  return (
    <div className="panel col-span-1 lg:col-span-1">
      <h2 className="panel-title">Quick-Start Checklist</h2>
      <ul>
        {checklist.map(item => (
          <li key={item.id} className="checklist-item">
            <input
              type="checkbox"
              id={item.id}
              checked={item.completed}
              onChange={() => onToggleItem(item.id)}
              aria-labelledby={`${item.id}-label`}
            />
            <label id={`${item.id}-label`} htmlFor={item.id} className={item.completed ? 'completed' : ''}>
              {item.text}
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
};
