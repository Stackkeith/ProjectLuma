/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

/**
 * Calculates the SHA-256 hash of a string.
 * @param input The string to hash.
 * @returns A promise that resolves to the SHA-256 hash as a hex string.
 */
export async function calculateSHA256(input: string): Promise<string> {
  const textAsBuffer = new TextEncoder().encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', textAsBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

/**
 * Generates an ephemeral AES-256 key from an entropy state object, as per the Entanglement Bridge protocol.
 * @param entropyState An object containing the data to be used as entropy.
 * @returns A promise that resolves to a 32-byte (256-bit) key as a hex string.
 */
export async function generateEntanglementKey(entropyState: object): Promise<string> {
  // Use a deterministic stringification for consistent entropy input.
  const sortedKeys = Object.keys(entropyState).sort();
  const entropyString = sortedKeys.map(key => `${key}:${JSON.stringify(entropyState[key])}`).join('|');
  
  const textAsBuffer = new TextEncoder().encode(entropyString);
  // As per Appendix B, use a strong hash. SHA-512 is a secure, widely available choice.
  const hashBuffer = await crypto.subtle.digest('SHA-512', textAsBuffer);
  
  // As per Appendix B, derive an AES key from the hash. Taking the first 32 bytes for AES-256.
  const keyBytes = hashBuffer.slice(0, 32);
  const keyArray = Array.from(new Uint8Array(keyBytes));
  const keyHex = keyArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  return keyHex;
}