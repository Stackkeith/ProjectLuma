/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React from 'react';
import { LogEntry } from './types';

interface TelemetryGraphProps {
  logHistory: LogEntry[];
}

export const TelemetryGraph: React.FC<TelemetryGraphProps> = ({ logHistory }) => {
  const reversedHistory = [...logHistory].reverse();
  const dataPoints = reversedHistory.length;
  
  const width = 500;
  const height = 300;
  const padding = 50;
  
  const getPath = (data: number[]) => {
    if (data.length < 2) return "";
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min;

    const scaleY = (val: number) => height - padding - ((val - min) / (range || 1)) * (height - 2 * padding);
    const scaleX = (index: number) => padding + (index / (dataPoints - 1)) * (width - 2 * padding);

    return data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${scaleX(i)} ${scaleY(d)}`).join(' ');
  };
  
  const hData = reversedHistory.map(e => e.H_current);
  const omegaData = reversedHistory.map(e => e.Omega_current);
  const tauData = reversedHistory.map(e => e.tau_current);

  const hPath = getPath(hData);
  const omegaPath = getPath(omegaData);
  const tauPath = getPath(tauData);

  const LegendItem: React.FC<{colorClass: string, label: string}> = ({colorClass, label}) => (
    <div className="flex items-center mr-4">
        <div className={`w-3 h-3 rounded-sm mr-2 ${colorClass}`}></div>
        <span className="text-xs">{label}</span>
    </div>
  );

  return (
    <div className="panel col-span-1 lg:col-span-1">
      <h2 className="panel-title">Telemetry Visualization</h2>
      {dataPoints < 2 ? (
        <div className="flex items-center justify-center h-full">
          <p className="text-gray-500 italic">Awaiting at least two sealed capsules for telemetry plot.</p>
        </div>
      ) : (
        <div>
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
                {/* Grid */}
                <path d={`M ${padding} ${padding} L ${padding} ${height - padding} L ${width - padding} ${height - padding}`} fill="none" className="graph-grid" strokeWidth="1"/>
                
                {/* Paths */}
                {hPath && <path d={hPath} fill="none" className="graph-line-h" strokeWidth="2" />}
                {omegaPath && <path d={omegaPath} fill="none" className="graph-line-omega" strokeWidth="2" />}
                {tauPath && <path d={tauPath} fill="none" className="graph-line-tau" strokeWidth="2" />}
                
                {/* Axis Labels */}
                <text x={padding - 10} y={height/2} className="graph-text" textAnchor="middle" transform={`rotate(-90, ${padding-10}, ${height/2})`}>Value (Normalized)</text>
                <text x={width/2} y={height - 15} className="graph-text" textAnchor="middle">Capsule History (Time →)</text>
            </svg>
            <div className="flex justify-center mt-4">
                <LegendItem colorClass="bg-cyan-400" label="H" />
                <LegendItem colorClass="bg-lime-400" label="Ω" />
                <LegendItem colorClass="bg-amber-400" label="τ" />
            </div>
        </div>
      )}
    </div>
  );
};
