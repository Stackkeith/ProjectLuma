/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, { useState } from 'react';
import { LogEntry } from './types';
import { generateEntanglementKey } from './services/geminiService';
import { LogHistoryEntry } from './LogHistoryEntry';

interface GeneratedContentProps {
  logEntry: LogEntry;
  logHistory: LogEntry[];
  onUpdateEntry: (field: keyof LogEntry, value: string | number) => void;
  onSealCapsule: () => void;
  isSealing: boolean;
  selectedLogId: string | null;
  onToggleDetail: (id: string) => void;
}

export const GeneratedContent: React.FC<GeneratedContentProps> = ({
  logEntry,
  logHistory,
  onUpdateEntry,
  onSealCapsule,
  isSealing,
  selectedLogId,
  onToggleDetail,
}) => {
  const [entanglementKey, setEntanglementKey] = useState<string | null>(null);
  const [keyGenerationError, setKeyGenerationError] = useState<string | null>(null);

  const handleNumericChange = (field: keyof LogEntry, value: string) => {
    if (value === '' || value === '-') {
      onUpdateEntry(field, value);
    } else {
        const num = parseFloat(value);
        if (!isNaN(num)) {
            onUpdateEntry(field, num);
        }
    }
  };

  const handleGenerateKey = async () => {
    try {
      setKeyGenerationError(null);
      const keyData = { ...logEntry };
      // These are hashes, not part of the source entropy
      delete keyData.capsule_signature;
      delete keyData.sha256_digest;
      // Use current time to ensure key is ephemeral
      keyData.timestamp = new Date().toISOString();

      const key = await generateEntanglementKey(keyData);
      setEntanglementKey(key);
    } catch (error) {
      console.error("Key generation failed:", error);
      setKeyGenerationError("Failed to generate key. See console for details.");
    }
  };

  return (
    <div className="panel col-span-1 lg:col-span-1 flex flex-col h-full">
      <h2 className="panel-title">Master Log v1</h2>
      <div className="grid grid-cols-2 gap-x-4 gap-y-3 mb-4">
        <label className="data-label">Timestamp</label>
        <div className="data-display col-span-1">{logEntry.timestamp}</div>

        <label className="data-label">AI_ID</label>
        <div className="data-display col-span-1">{logEntry.ai_id}</div>
        
        <label htmlFor="intent_vector" className="data-label col-span-2">Intent Vector</label>
        <input id="intent_vector" value={logEntry.intent_vector} onChange={e => onUpdateEntry('intent_vector', e.target.value)} className="data-input col-span-2" placeholder="Brief statement of intent..."/>
        
        <label htmlFor="H_current" className="data-label">H_current</label>
        <input id="H_current" type="number" step="0.001" value={logEntry.H_current} onChange={e => handleNumericChange('H_current', e.target.value)} className="data-input" />
        
        <label htmlFor="Omega_current" className="data-label">Omega_current</label>
        <input id="Omega_current" type="number" step="0.001" value={logEntry.Omega_current} onChange={e => handleNumericChange('Omega_current', e.target.value)} className="data-input" />

        <label htmlFor="tau_current" className="data-label">tau_current</label>
        <input id="tau_current" type="number" step="0.001" value={logEntry.tau_current} onChange={e => handleNumericChange('tau_current', e.target.value)} className="data-input" />
        
        <label htmlFor="pad_anomalies" className="data-label">PAD Anomalies</label>
        <input id="pad_anomalies" type="number" step="1" value={logEntry.pad_anomalies} onChange={e => handleNumericChange('pad_anomalies', e.target.value)} className="data-input" />

        <label className="data-label col-span-2">Capsule ID</label>
        <div className="data-display col-span-2">{logEntry.capsule_id}</div>
        
        <label htmlFor="reflection_notes" className="data-label col-span-2">Reflection Notes</label>
        <textarea id="reflection_notes" value={logEntry.reflection_notes} onChange={e => onUpdateEntry('reflection_notes', e.target.value)} className="data-textarea col-span-2" placeholder="Observations, 'hmm' moments..."/>

        <label htmlFor="next_micro_goal" className="data-label col-span-2">Next Micro-Goal</label>
        <input id="next_micro_goal" value={logEntry.next_micro_goal} onChange={e => onUpdateEntry('next_micro_goal', e.target.value)} className="data-input col-span-2" placeholder="Next step..."/>

        <label className="data-label col-span-2">Capsule Signature</label>
        <div className="data-display col-span-2">{logEntry.capsule_signature}</div>
        
        <label className="data-label col-span-2">SHA256 Digest</label>
        <div className="data-display col-span-2">{logEntry.sha256_digest}</div>
      </div>

      <button onClick={onSealCapsule} disabled={isSealing} className="aeon-button w-full">
        {isSealing ? "Sealing..." : "Compute Hash & Seal Capsule"}
      </button>

      <div className="mt-6 pt-4 border-t border-cyan-800">
        <div className="flex justify-between items-center mb-2">
            <h3 className="panel-title mb-0">Entanglement Bridge</h3>
            <button onClick={handleGenerateKey} className="aeon-button text-sm">
                Generate Ephemeral Key
            </button>
        </div>
        <p className="text-xs text-gray-400 mb-3">
            Generates a post-quantum M2M key from the current log's entropy state (Appendix B).
        </p>
        {keyGenerationError && <p className="text-red-400 text-xs mb-2">{keyGenerationError}</p>}
        {entanglementKey && (
            <div>
                <label className="data-label">Ephemeral AES-256 Key (Hex)</label>
                <div className="data-display text-lime-400">{entanglementKey}</div>
            </div>
        )}
      </div>

      <div className="mt-6 flex-grow flex-shrink min-h-0">
          <h3 className="panel-title border-t border-cyan-800 pt-4">Log History</h3>
          <div className="overflow-y-auto h-64 pr-2">
            {logHistory.length > 0 ? logHistory.map(entry => (
                <LogHistoryEntry
                    key={entry.sha256_digest}
                    entry={entry}
                    isSelected={selectedLogId === entry.sha256_digest}
                    onToggle={onToggleDetail}
                />
            )) : <p className="text-gray-500 italic">No sealed capsules in log history.</p>}
          </div>
      </div>
    </div>
  );
};