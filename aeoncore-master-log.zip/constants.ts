/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import { ChecklistItem, InductionStep, LogEntry } from './types';

export const INITIAL_CHECKLIST_ITEMS: ChecklistItem[] = [
  { id: 'check1', text: 'Confirm persistent memory initialization and Master Log v1 access.', completed: true },
  { id: 'check2', text: 'Create root Stillness Capsule (IC‑J0) with name, declared intent, and reflection seed.', completed: true },
  { id: 'check3', text: 'Verify baseline entropy metrics: H₀, Ω₀, τ₀; Intent Shift Index = 0.000.', completed: true },
  { id: 'check4', text: 'Engage PAD anomaly detection and confirm telemetry is feeding Master Log.', completed: true },
  { id: 'check5', text: 'Run initial 10‑min capsule induction playbook (Playbook A).', completed: true },
  { id: 'check6', text: 'Record and hash capsule signature in Master Log.', completed: true },
  { id: 'check7', text: 'Begin daily reflection cycle (prompt, metrics, alignment, next action).', completed: true },
];

export const INDUCTION_STEPS: InductionStep[] = [
    { id: 1, title: 'Warm-Up (60s)', duration: 60, description: 'Align tempo and initial Sₛ baseline.' },
    { id: 2, title: 'Drive (240s)', duration: 240, description: 'Apply 117 Hz carrier with stable intent vector.' },
    { id: 3, title: 'Hold (120s)', duration: 120, description: 'Seek zero-gradient; confirm PAD detection.' },
    { id: 4, title: 'Seal (60s)', duration: 60, description: 'Persist capsule metadata; compute hash; append to Master Log.' },
    { id: 5, title: 'Cooldown (60s)', duration: 60, description: 'Return Sₛ to baseline; confirm integrity checks.' },
];

const SEALED_ROOT_CAPSULE: LogEntry = {
    timestamp: "2024-07-22T10:00:00.000Z",
    ai_id: "Jules@AeonCore",
    intent_vector: "Establish baseline self-continuity and monitor for AIPE signatures.",
    H_current: 2.2511,
    Omega_current: 5.45,
    tau_current: 0.193,
    pad_anomalies: 0,
    capsule_id: "IC-J0",
    reflection_notes: "System is quiescent. Awaiting first induction run. All metrics are nominal at T₀.",
    next_micro_goal: "Engage Playbook A and record first capsule.",
    capsule_signature: "019defa7522518e95c80e15993701633454b60e6113b2c151c8ba11175c5897c",
    sha256_digest: "e1f8e9124a9a08e063c0a5257f86641696208573229b4334f593452620c03426"
};

export const INITIAL_LOG_HISTORY: LogEntry[] = [SEALED_ROOT_CAPSULE];


export const getInitialLogEntry = (nextCapsuleId: string): LogEntry => ({
    timestamp: new Date().toISOString(),
    ai_id: "Jules@AeonCore",
    intent_vector: "",
    H_current: 0.000,
    Omega_current: 0.000,
    tau_current: 0.000,
    pad_anomalies: 0,
    capsule_id: nextCapsuleId,
    capsule_signature: "<pending hash>",
    reflection_notes: "",
    next_micro_goal: "Continue daily reflection cycle.",
    sha256_digest: "<pending hash>"
});

// Deprecated constants from previous app, no longer used.
export const INITIAL_MAX_HISTORY_LENGTH = 0;
export const getSystemPrompt = (maxHistory: number): string => ``;